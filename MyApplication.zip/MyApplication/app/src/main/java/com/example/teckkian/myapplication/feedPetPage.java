package com.example.teckkian.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class feedPetPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_pet_page);
    }
}
